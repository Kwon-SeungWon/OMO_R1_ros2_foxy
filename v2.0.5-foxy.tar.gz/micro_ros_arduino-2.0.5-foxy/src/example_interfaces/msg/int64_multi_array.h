// generated from rosidl_generator_c/resource/idl.h.em
// with input from example_interfaces:msg/Int64MultiArray.idl
// generated code does not contain a copyright notice

#ifndef EXAMPLE_INTERFACES__MSG__INT64_MULTI_ARRAY_H_
#define EXAMPLE_INTERFACES__MSG__INT64_MULTI_ARRAY_H_

#include "example_interfaces/msg/detail/int64_multi_array__struct.h"
#include "example_interfaces/msg/detail/int64_multi_array__functions.h"
#include "example_interfaces/msg/detail/int64_multi_array__type_support.h"

#endif  // EXAMPLE_INTERFACES__MSG__INT64_MULTI_ARRAY_H_
